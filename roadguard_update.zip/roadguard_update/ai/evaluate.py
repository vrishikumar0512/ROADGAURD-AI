"""
Quantitative evaluation for RoadGuard AI.

Reports:
  - mAP@0.5 and mAP@0.5:0.95 (Ultralytics validation)
  - Precision / Recall / F1 at a fixed confidence threshold
  - False positive rate (FP / total predictions) and false negatives
  - Inference latency per frame (mean, median, p95) and FPS
  - Per-class AP@0.5

    python ai/evaluate.py --weights ai/models/road_damage.pt \
        --data ai/data/road_damage.yaml --split test --conf 0.25

Results are written to ai/runs/eval_results.json and eval_results.csv.
"""
import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np


def iou(a, b):
    """IoU of two boxes in [x1, y1, x2, y2]."""
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter / union if union > 0 else 0.0


def load_gt(label_file, w, h):
    """YOLO txt (cls cx cy bw bh, normalised) -> list of (cls, xyxy pixels)."""
    gts = []
    if label_file.exists():
        for line in label_file.read_text().splitlines():
            p = line.split()
            if len(p) < 5:
                continue
            c, cx, cy, bw, bh = int(p[0]), *map(float, p[1:5])
            gts.append((c, [(cx-bw/2)*w, (cy-bh/2)*h, (cx+bw/2)*w, (cy+bh/2)*h]))
    return gts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default="ai/models/road_damage.pt")
    ap.add_argument("--data", default="ai/data/road_damage.yaml")
    ap.add_argument("--split", default="test", choices=["val", "test"])
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--iou-thr", type=float, default=0.5)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--warmup", type=int, default=5)
    args = ap.parse_args()

    import yaml
    from PIL import Image
    from ultralytics import YOLO

    model = YOLO(args.weights)

    # 1) mAP via Ultralytics
    m = model.val(data=args.data, split=args.split, imgsz=args.imgsz, verbose=False)
    names = model.names
    per_class_ap50 = {names[int(c)]: float(v)
                      for c, v in zip(m.box.ap_class_index, m.box.ap50)}

    # 2) Precision/Recall/FP-rate + latency on the same split
    cfg = yaml.safe_load(open(args.data))
    root = Path(cfg["path"])
    img_dir = root / cfg[args.split]
    lbl_dir = Path(str(img_dir).replace("images", "labels"))
    images = sorted(p for p in img_dir.glob("*") if p.suffix.lower() in
                    (".jpg", ".jpeg", ".png"))
    if not images:
        raise SystemExit(f"No images found in {img_dir}")

    for p in images[:args.warmup]:                       # GPU/CPU warm-up
        model.predict(str(p), conf=args.conf, imgsz=args.imgsz, verbose=False)

    tp = fp = fn = 0
    latencies = []
    for p in images:
        w, h = Image.open(p).size
        gts = load_gt(lbl_dir / f"{p.stem}.txt", w, h)

        t0 = time.perf_counter()
        r = model.predict(str(p), conf=args.conf, imgsz=args.imgsz, verbose=False)[0]
        latencies.append((time.perf_counter() - t0) * 1000)

        preds = sorted(
            [(int(b.cls), b.xyxy[0].tolist(), float(b.conf)) for b in r.boxes],
            key=lambda x: -x[2])
        matched = set()
        for c, box, _ in preds:
            best, best_i = 0.0, -1
            for i, (gc, gbox) in enumerate(gts):
                if i in matched or gc != c:
                    continue
                s = iou(box, gbox)
                if s > best:
                    best, best_i = s, i
            if best >= args.iou_thr:
                tp += 1
                matched.add(best_i)
            else:
                fp += 1
        fn += len(gts) - len(matched)

    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2*precision*recall / (precision + recall) if precision + recall else 0.0
    lat = np.array(latencies)

    results = {
        "weights": args.weights, "split": args.split, "images": len(images),
        "conf_threshold": args.conf, "iou_threshold": args.iou_thr,
        "mAP@0.5": round(float(m.box.map50), 4),
        "mAP@0.5:0.95": round(float(m.box.map), 4),
        "precision": round(precision, 4), "recall": round(recall, 4),
        "f1": round(f1, 4),
        "false_positive_rate": round(fp / (tp + fp), 4) if tp + fp else 0.0,
        "false_positives": fp, "false_negatives": fn, "true_positives": tp,
        "latency_ms_mean": round(float(lat.mean()), 2),
        "latency_ms_median": round(float(np.median(lat)), 2),
        "latency_ms_p95": round(float(np.percentile(lat, 95)), 2),
        "fps": round(1000 / float(lat.mean()), 2),
        "per_class_AP@0.5": per_class_ap50,
    }

    out = Path("ai/runs"); out.mkdir(parents=True, exist_ok=True)
    (out / "eval_results.json").write_text(json.dumps(results, indent=2))
    with open(out / "eval_results.csv", "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["metric", "value"])
        for k, v in results.items():
            if not isinstance(v, dict):
                wr.writerow([k, v])
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
