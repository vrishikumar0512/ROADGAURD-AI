"""
EXIF GPS extraction for RoadGuard AI.

Reads latitude / longitude (and capture time) from an uploaded image so the
user no longer has to type coordinates manually.

Usage:
    from ai.exif_utils import extract_gps
    gps = extract_gps("uploads/original/photo.jpg")
    # -> {"latitude": 11.0, "longitude": 77.0, "altitude": 410.2,
    #     "timestamp": "2026:10:05 10:14:22", "source": "exif"}  or  None
"""
from __future__ import annotations

from typing import Optional
from PIL import Image, ExifTags

GPS_IFD = 0x8825        # GPSInfo pointer tag
EXIF_IFD = 0x8769       # Exif sub-IFD pointer tag


def _to_float(v) -> float:
    """Pillow returns IFDRational or (num, den) tuples depending on version."""
    if isinstance(v, tuple) and len(v) == 2:
        return float(v[0]) / float(v[1]) if v[1] else 0.0
    return float(v)


def _dms_to_decimal(dms, ref) -> Optional[float]:
    try:
        deg, minutes, seconds = (_to_float(x) for x in dms)
    except Exception:
        return None
    value = deg + minutes / 60.0 + seconds / 3600.0
    if isinstance(ref, bytes):
        ref = ref.decode(errors="ignore")
    if str(ref).strip().upper() in ("S", "W"):
        value = -value
    return value


def extract_gps(image_path: str) -> Optional[dict]:
    """Return GPS data from the image's EXIF block, or None if absent/invalid."""
    try:
        with Image.open(image_path) as img:
            exif = img.getexif()
            if not exif:
                return None
            gps = exif.get_ifd(GPS_IFD)
            if not gps:
                return None

            # GPS tag ids: 1=LatRef 2=Lat 3=LonRef 4=Lon 5=AltRef 6=Alt
            lat_ref, lat = gps.get(1), gps.get(2)
            lon_ref, lon = gps.get(3), gps.get(4)
            if not (lat and lon and lat_ref and lon_ref):
                return None

            latitude = _dms_to_decimal(lat, lat_ref)
            longitude = _dms_to_decimal(lon, lon_ref)
            if latitude is None or longitude is None:
                return None
            if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
                return None
            if latitude == 0 and longitude == 0:   # common "no fix" placeholder
                return None

            altitude = None
            if gps.get(6) is not None:
                altitude = _to_float(gps[6])
                if gps.get(5) in (1, b"\x01"):
                    altitude = -altitude

            timestamp = exif.get_ifd(EXIF_IFD).get(0x9003) or exif.get(0x0132)

            return {
                "latitude": round(latitude, 6),
                "longitude": round(longitude, 6),
                "altitude": altitude,
                "timestamp": str(timestamp) if timestamp else None,
                "source": "exif",
            }
    except Exception:
        return None


def resolve_location(image_path: str, form_lat=None, form_lng=None) -> dict:
    """
    Priority: EXIF GPS -> browser/manual coordinates -> unknown.
    Always tells the caller where the coordinates came from.
    """
    gps = extract_gps(image_path)
    if gps:
        return gps
    try:
        if form_lat not in (None, "") and form_lng not in (None, ""):
            return {"latitude": float(form_lat), "longitude": float(form_lng),
                    "altitude": None, "timestamp": None, "source": "manual"}
    except (TypeError, ValueError):
        pass
    return {"latitude": None, "longitude": None, "altitude": None,
            "timestamp": None, "source": "unknown"}
