"""
Fine-tune YOLOv8 on a road-damage dataset (RDD2022 or Roboflow export).

    pip install ultralytics torch
    python ai/train_yolo.py --data ai/data/road_damage.yaml --epochs 50

The best weights are copied to ai/models/road_damage.pt, which ai/detector.py
auto-loads, switching the UI from Demo AI Mode to PRODUCTION YOLO INFERENCE.
"""
import argparse
import shutil
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="ai/data/road_damage.yaml")
    ap.add_argument("--base", default="yolov8n.pt", help="yolov8n/s/m.pt")
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--device", default=None, help="'cpu', '0', etc.")
    args = ap.parse_args()

    from ultralytics import YOLO

    model = YOLO(args.base)
    model.train(data=args.data, epochs=args.epochs, imgsz=args.imgsz,
                batch=args.batch, device=args.device,
                project="ai/runs", name="road_damage", exist_ok=True,
                patience=15)

    best = Path("ai/runs/road_damage/weights/best.pt")
    out = Path("ai/models/road_damage.pt")
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(best, out)
    print(f"Saved trained weights -> {out}")


if __name__ == "__main__":
    main()
