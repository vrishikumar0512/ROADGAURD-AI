# RoadGuard AI – Update Guide (review feedback fixes)

Copy the `ai/` files from this package into your project (merge folders), then follow the 3 steps.

## 1. Requirements
Add to `requirements.txt`:
```
ultralytics
torch
pyyaml
```

## 2. Fix #1 – Replace OpenCV heuristics with a trained YOLOv8 model
1. Download RDD2022 (or a Roboflow road-damage export in YOLO format) into `ai/data/road_damage_dataset/`.
2. Make sure the class order in `ai/data/road_damage.yaml` matches your `ai/detector.py` class list.
3. Train:
   ```
   python ai/train_yolo.py --data ai/data/road_damage.yaml --epochs 50
   ```
   Weights are saved to `ai/models/road_damage.pt`, which your detector already auto-loads
   (UI switches from Demo AI Mode to PRODUCTION YOLO INFERENCE). Keep the OpenCV mode as the fallback.

## 3. Fix #2 – Auto-extract GPS from EXIF on upload
In your `POST /api/detect` route (backend), after saving the uploaded file:
```python
from ai.exif_utils import resolve_location

loc = resolve_location(saved_path,
                       request.form.get("latitude"),
                       request.form.get("longitude"))
latitude, longitude = loc["latitude"], loc["longitude"]
# Return loc["source"] ("exif" | "manual" | "unknown") in the JSON response
# and show it in the UI, e.g. "Location: EXIF GPS" or "Location: manual".
```
Frontend (`/detect` page): make the lat/lng inputs optional and show
"GPS read from photo" when `source == "exif"`. Note: WhatsApp and many social apps strip EXIF,
so test with the original camera file.

## 4. Fix #3 – Quantitative evaluation
```
python ai/evaluate.py --weights ai/models/road_damage.pt --data ai/data/road_damage.yaml --split test
```
Outputs `ai/runs/eval_results.json` / `.csv` with: mAP@0.5, mAP@0.5:0.95, precision, recall, F1,
false positive rate, FP/FN counts, latency per frame (mean/median/p95), FPS, per-class AP@0.5.

## README section to paste
```
## 11. Evaluation Metrics
| Metric | Definition | Target |
|---|---|---|
| mAP@0.5 | Mean average precision at IoU 0.5 | >= 0.50 |
| Precision / Recall | At conf 0.25, IoU 0.5 | report both |
| False positive rate | FP / (TP + FP) | <= 0.20 |
| Latency per frame | Mean / p95 inference time (ms) | <= 100 ms (GPU) |
Run `python ai/evaluate.py` to reproduce; results are saved to `ai/runs/eval_results.json`.

## 12. GPS Metadata
Uploads are scanned for EXIF GPS (`ai/exif_utils.py`). If absent, the browser/manual
coordinates are used and the source is recorded.
```
